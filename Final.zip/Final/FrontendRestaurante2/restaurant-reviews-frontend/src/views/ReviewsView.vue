<template>
  <div class="reviews-container">
    <h1>Reseñas</h1>

    <!-- Formulario para agregar una reseña -->
    <div v-if="token" class="add-review-form">
      <h2>Agregar Reseña</h2>
      <form @submit.prevent="onAddReview">
        <label for="restaurant">Nombre del Restaurante:</label>
        <input type="text" id="restaurant" v-model="newReview.restaurantName" required />

        <label for="rating">Calificación (1-5):</label>
        <input type="number" id="rating" v-model="newReview.rating" min="1" max="5" required />

        <label for="comment">Comentario:</label>
        <textarea id="comment" v-model="newReview.comment" required></textarea>

        <button type="submit">Agregar Reseña</button>
      </form>
    </div>

    <!-- Lista de reseñas -->
    <div v-for="review in reviews" :key="review._id" class="review-card">
      <h3>{{ review.restaurantName }}</h3>
      <p><strong>Calificación:</strong> {{ review.rating }} / 5</p>
      <p><strong>Comentario:</strong> {{ review.comment }}</p>
      <p class="review-user"><strong>Usuario:</strong> {{ review.user.name }}</p>

      <!-- Botones para el usuario autenticado -->
      <div v-if="review.user._id === currentUserId" class="actions">
        <button class="edit-btn" @click="enableEdit(review)">Editar</button>
        <button class="delete-btn" @click="onDeleteReview(review._id)">Eliminar</button>
      </div>

      <!-- Formulario de edición -->
      <div v-if="editingReviewId === review._id" class="edit-section">
        <textarea v-model="editText" rows="4"></textarea>
        <button class="save-btn" @click="onUpdateReview(review._id)">Guardar</button>
        <button class="cancel-btn" @click="cancelEdit">Cancelar</button>
      </div>
    </div>
  </div>
</template>

<script>
import {
  getAllReviews,
  addReview,
  updateReview,
  deleteReview,
} from "../services/reviewService";

export default {
  data() {
    return {
      reviews: [], // Lista de reseñas
      newReview: {
        restaurantName: "",
        rating: "",
        comment: "",
      },
      editText: "",
      editingReviewId: null,
      currentUserId: null,
      token: null,
    };
  },
  methods: {
    async fetchReviews() {
      try {
        this.reviews = await getAllReviews();
      } catch (error) {
        console.error(error);
      }
    },
    async onAddReview() {
      try {
        const review = await addReview(this.newReview, this.token);
        this.reviews.push(review);
        this.newReview = { restaurantName: "", rating: "", comment: "" };
        window.location.reload();
      } catch (error) {
        console.error(error);
      }
    },
    enableEdit(review) {
      this.editingReviewId = review._id;
      this.editText = review.comment;
    },
    async onUpdateReview(id) {
      try {
        const updatedReview = await updateReview(
          id,
          { comment: this.editText },
          this.token
        );
        const review = this.reviews.find((r) => r._id === id);
        review.comment = updatedReview.comment;
        this.cancelEdit();
      } catch (error) {
        console.error(error);
      }
    },
    cancelEdit() {
      this.editingReviewId = null;
      this.editText = "";
    },
    async onDeleteReview(id) {
      try {
        await deleteReview(id, this.token);
        this.reviews = this.reviews.filter((r) => r._id !== id);
      } catch (error) {
        console.error(error);
      }
    },
  },
  mounted() {
    this.token = sessionStorage.getItem("token");
    const payload = JSON.parse(atob(this.token.split(".")[1])); // Decodifica el token
    this.currentUserId = payload.id; // Extrae el ID del usuario actual
    this.fetchReviews();
  },
};
</script>

<style scoped>
/* Contenedor principal */
.reviews-container {
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  font-family: 'Arial', sans-serif;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* Título principal */
h1 {
  text-align: center;
  color: #333;
  margin-bottom: 20px;
  font-size: 2rem;
}

/* Formulario de agregar reseña */
.add-review-form {
  margin-bottom: 30px;
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.add-review-form h2 {
  margin-bottom: 15px;
  color: #007bff;
}

.add-review-form label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #555;
}

.add-review-form input,
.add-review-form textarea {
  width: 100%;
  margin-bottom: 15px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.add-review-form button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.add-review-form button:hover {
  background-color: #0056b3;
}

/* Tarjetas de reseña */
.review-card {
  border: 1px solid #ddd;
  padding: 15px;
  margin-bottom: 15px;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.review-card h3 {
  color: #007bff;
}

.review-card p {
  margin: 5px 0;
  color: #333;
}

.review-user {
  font-style: italic;
  color: #666;
}

/* Botones */
button {
  margin: 5px;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

.edit-btn {
  background-color: #007bff;
  color: white;
}

.edit-btn:hover {
  background-color: #0056b3;
}

.delete-btn {
  background-color: #dc3545;
  color: white;
}

.delete-btn:hover {
  background-color: #a71d2a;
}

.save-btn {
  background-color: #28a745;
  color: white;
}

.save-btn:hover {
  background-color: #1e7e34;
}

.cancel-btn {
  background-color: #6c757d;
  color: white;
}

.cancel-btn:hover {
  background-color: #545b62;
}

/* Área de edición */
.edit-section {
  margin-top: 15px;
}

.edit-section textarea {
  width: 100%;
  margin-bottom: 10px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
}
</style>
