<template>
  <div class="login-container">
    <h1>Bienvenido</h1>
    <h2>Inicia Sesión</h2>
    <form @submit.prevent="onSubmit">
      <label for="email">Correo Electrónico:</label>
      <input type="email" id="email" v-model="email" />

      <label for="password">Contraseña:</label>
      <input type="password" id="password" v-model="password" />

      <button type="submit">Iniciar Sesión</button>
    </form>
    <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
  </div>
</template>

<script>
import { login } from '../services/authService'; // Importa el servicio de autenticación

export default {
  data() {
    return {
      email: '',
      password: '',
      errorMessage: '', // Mensaje de error
    };
  },
  methods: {
    async onSubmit() {
      try {
        // Llama al servicio de login con las credenciales del usuario
        const { token } = await login(this.email, this.password);

        // Guarda el token en sessionStorage
        sessionStorage.setItem('token', token);

        // Redirige al usuario a otra página después de iniciar sesión (ejemplo: `/reviews`)
        this.$router.push('/reviews');
      } catch (error) {
        this.errorMessage = error; // Muestra el error si ocurre algo
      }
    },
  },
};
</script>

<style scoped>
/* Contenedor principal */
.login-container {
  max-width: 400px;
  margin: 150px auto;
  padding: 20px;
  border: 3px solid #ccc;
  border-radius: 8px;
  background-color: rgba(255, 255, 255, 0.9);
  text-align: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Estilo del encabezado */
h1 {
  font-size: 2rem;
  color: #007bff;
  margin-bottom: 10px;
}

h2 {
  margin-bottom: 20px;
  color: #333;
}

/* Estilo de etiquetas y entradas */
label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
}

input {
  width: 80%;
  padding: 8px;
  margin-bottom: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

/* Botón */
button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Mensaje de error */
.error {
  color: #dc3545;
  margin-top: 15px;
}
</style>
