<template>
  <div class="reviews-container">
    <h1>Reseñas</h1>
    <div v-for="review in reviews" :key="review.id" class="review-card">
      <div class="review-header">
        <h3>{{ review.usuario }}</h3>
        <p><strong>Fecha:</strong> {{ review.fechaCreacion }}</p>
      </div>
      <p><strong>Restaurante:</strong> {{ review.nombreRestaurante }}</p>
      <p><strong>Comentario:</strong> {{ review.comentario }}</p>

      <div v-if="review.usuario === currentUser" class="actions">
        <button class="edit-btn" @click="enableEdit(review.id)">Editar</button>
        <button class="delete-btn" @click="deleteReview(review.id)">Eliminar</button>
      </div>

      <div v-if="editingReviewId === review.id" class="edit-section">
        <textarea v-model="editText" rows="4"></textarea>
        <button class="save-btn" @click="saveEdit(review.id)">Guardar</button>
        <button class="cancel-btn" @click="cancelEdit">Cancelar</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ReviewsList",
  data() {
    return {
      currentUser: "Juan Pérez",
      reviews: [
        {
          id: 1,
          usuario: "Juan Pérez",
          fechaCreacion: "2024-11-29",
          nombreRestaurante: "La Parrilla",
          comentario: "Excelente comida y servicio.",
        },
        {
          id: 2,
          usuario: "Ana López",
          fechaCreacion: "2024-11-28",
          nombreRestaurante: "Pizza Express",
          comentario: "Rápido y delicioso.",
        },
      ],
      editingReviewId: null,
      editText: "",
    };
  },
  methods: {
    enableEdit(id) {
      const review = this.reviews.find((r) => r.id === id);
      this.editingReviewId = id;
      this.editText = review.comentario;
    },
    saveEdit(id) {
      const review = this.reviews.find((r) => r.id === id);
      review.comentario = this.editText;
      this.editingReviewId = null;
      this.editText = "";
    },
    cancelEdit() {
      this.editingReviewId = null;
      this.editText = "";
    },
    deleteReview(id) {
      this.reviews = this.reviews.filter((review) => review.id !== id);
    },
  },
};
</script>

<style scoped>
/* Contenedor principal */
.reviews-container {
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  font-family: 'Arial', sans-serif;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* Título principal */
h1 {
  text-align: center;
  color: #333;
  margin-bottom: 20px;
}

/* Tarjetas de reseña */
.review-card {
  border: 1px solid #ddd;
  padding: 20px;
  margin-bottom: 15px;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Cabecera de la reseña */
.review-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

/* Botones */
button {
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

.edit-btn {
  background-color: #007bff;
  color: white;
  margin-right: 10px;
}

.edit-btn:hover {
  background-color: #0056b3;
}

.delete-btn {
  background-color: #dc3545;
  color: white;
}

.delete-btn:hover {
  background-color: #a71d2a;
}

.save-btn {
  background-color: #28a745;
  color: white;
}

.save-btn:hover {
  background-color: #1e7e34;
}

.cancel-btn {
  background-color: #6c757d;
  color: white;
}

.cancel-btn:hover {
  background-color: #545b62;
}

/* Área de edición */
.edit-section {
  margin-top: 15px;
}

textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 14px;
}

/* Acciones */
.actions {
  margin-top: 10px;
}
</style>
