import { createRouter, createWebHistory } from 'vue-router';

// Importa las vistas
import LoginView from '../views/LoginView.vue';
import RegisterView from '../views/RegisterView.vue';
import ReviewsView from '../views/ReviewsView.vue';

// Define las rutas
const routes = [
  {
    path: '/login',
    name: 'Login',
    component: LoginView,
  },
  {
    path: '/register',
    name: 'Register',
    component: RegisterView,
  },
  {
    path: '/reviews',
    name: 'Reviews',
    component: ReviewsView,
  },
  {
    path: '/',
    redirect: '/login', 
  },
];

// Crea el enrutador
const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
