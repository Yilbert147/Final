import axios from 'axios';

const API_URL = 'http://localhost:5000/api/auth'; // Cambia esta URL si tu backend usa otro puerto o ruta base.

// Servicio de autenticación
export const login = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/login`, { email, password });
    return response.data; // Retorna los datos de la respuesta (por ejemplo, el token).
  } catch (error) {
    throw error.response?.data?.message || 'Error al iniciar sesión';
  }
};
// Servicio para registro de usuarios
export const register = async (name, email, password) => {
    try {
      const response = await axios.post(`${API_URL}/register`, { name, email, password });
      return response.data; // Devuelve los datos del backend (por ejemplo, un mensaje de éxito).
    } catch (error) {
      throw error.response?.data?.message || 'Error al registrar usuario';
    }
  };