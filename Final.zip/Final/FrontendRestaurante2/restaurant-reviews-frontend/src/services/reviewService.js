import axios from 'axios';

const API_URL = 'http://localhost:5000/api/reviews'; // URL base para las reseñas

// Obtener todas las reseñas
export const getAllReviews = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Error al obtener reseñas';
  }
};

// Agregar una nueva reseña
export const addReview = async (review, token) => {
  try {
    const response = await axios.post(API_URL, review, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Error al agregar reseña';
  }
};

// Actualizar una reseña
export const updateReview = async (id, updatedReview, token) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, updatedReview, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Error al actualizar reseña';
  }
};

// Eliminar una reseña
export const deleteReview = async (id, token) => {
  try {
    const response = await axios.delete(`${API_URL}/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Error al eliminar reseña';
  }
};
