import axios from 'axios';
import { createApp } from 'vue';
import App from './App.vue';
import router from './router';

axios.defaults.baseURL = 'http://localhost:5000/api'; 
axios.defaults.headers.common['Content-Type'] = 'application/json';

const app = createApp(App);
app.config.globalProperties.$axios = axios; 
app.use(router);
app.mount('#app');
